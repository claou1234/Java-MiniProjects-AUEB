# Java - SEV/AUEB(Skills4Jobs) - Mini Projects
A multitude of Java mini projects and exercises from the SEV/AUEB Skills4Job camp.
